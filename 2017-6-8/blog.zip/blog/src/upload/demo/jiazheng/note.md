http://42.123.125.46:4333/home

cd /Users/zhaixingfy/Desktop/learn/www/jiazheng/jiazheng

sudo browser-sync start --server ./ --files * --no-notify